import { Logon } from './model/logon';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Registration } from './model/registration';
import { Router } from '@angular/router';
import { EditCustomer } from './model/editcustomer';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  logon = new Logon();
  receivedObj: Registration;
  baseHref = 'http://localhost:8880';

  constructor(private http: HttpClient, private routes: Router) {
  }
  login(logon: Logon) {
    console.log(logon);
    return this.http.post<Logon>(this.baseHref + '/add', logon);
  }
  registerDetails(register: Registration) {
    console.log(register);
    return this.http.post<Logon>(this.baseHref + '/register', register);
  }
  edit(editedDetails: EditCustomer): any {
    console.log(editedDetails);
    return this.http.post<Logon>(this.baseHref + '/edit', editedDetails);
  }
}
