import { Component, OnInit } from '@angular/core';
import { Registration } from '../model/registration';
import { customer } from '../model/customerpage';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-customer-page',
  templateUrl: './customer-page.component.html',
  styleUrls: ['./customer-page.component.css']
})
export class CustomerPageComponent implements OnInit {

  registeredDetails: Registration;

  constructor(private serviceService: ServiceService, private router: Router) {
    this.registeredDetails = new Registration();
  }

  ngOnInit() {

  }
  navigateToEdit() {

    this.router.navigate(['/edit-customer']);

  }

}
