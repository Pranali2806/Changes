import { NgModule } from '@angular/core';
import {MatButtonModule, MatSidenav, MatNavList, MatSidenavContent, 
  MatSidenavContainer, MatToolbarModule, MatDatepickerModule, MatDatepicker, MatNativeDateModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import {MatListModule} from '@angular/material/list';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatInputModule} from '@angular/material/input';

@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatIconModule,MatToolbarModule,
    MatListModule,
    MatGridListModule,
    MatCardModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  exports:[
    MatButtonModule,MatMenuModule,MatIconModule,MatToolbarModule,
    MatGridListModule,
    MatListModule,
    MatCardModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule
  ]
})
export class MaterialModule { }
