import { TestBed } from '@angular/core/testing';

import { CommonAdminService } from './common-admin.service';

describe('CommonAdminService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CommonAdminService = TestBed.get(CommonAdminService);
    expect(service).toBeTruthy();
  });
});
