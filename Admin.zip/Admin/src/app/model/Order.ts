export class Order{
  id:number;
  date:string;
  amount:number;
}
