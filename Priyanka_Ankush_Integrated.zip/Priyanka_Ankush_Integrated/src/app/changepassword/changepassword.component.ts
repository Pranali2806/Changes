import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';
import { PasswordService } from '../service/password.service';
import { FormControl, Validators } from '@angular/forms';
import * as sha1 from 'sha1/sha1';
@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  user: UserModel;
  incorrectPasswordStatus = false;
  userArr: UserModel[] = [];
  conversionEncryptOutput: string;

  // form controls
  passwordControl = new FormControl('', [
    Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]);
  repeatPasswordControl = new FormControl('', []);
  
  constructor(private passwordService: PasswordService) {
  this.user = new UserModel();
  }

  ngOnInit() {
  }

  // validate password and confirm password
  validateboth() {
    if (this.user.newPassword !== '') {
      if (this.user.newPassword === this.user.confirmPassword) {
        // password matches
      } else {
        this.repeatPasswordControl.setErrors(Validators.requiredTrue);
      }
    }
  }
  cancel() {
    this.user.currentPassword = '';
    this.user.confirmPassword = '';
    this.user.newPassword = '';
  }
  // on blur event of current password,it is sent to db to check if its correct
  // the post request returns boolean,if its false show error
  validateCurrentPassword() {
    this.conversionEncryptOutput = sha1(this.user.currentPassword);
    this.passwordService.verifyPassword(this.conversionEncryptOutput).subscribe(
      result => {
        console.log(result);
      },
      error => {
        console.log(error);
      }
    );
  }
  // submit new password to db
  submitNewPassword() {
    this.conversionEncryptOutput = sha1(this.user.newPassword);
    this.user.newPassword = this.conversionEncryptOutput;
    this.passwordService.submitNewPassword(this.user.newPassword).subscribe(
      result => {
        console.log(result);
      },
      error => {
        console.log(error);
      }
    );
  }
}
