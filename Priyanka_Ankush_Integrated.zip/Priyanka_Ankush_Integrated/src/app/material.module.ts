import { NgModule } from '@angular/core';
import { MatButtonModule, MatDatepickerModule, MatNativeDateModule, MatCardModule } from '@angular/material';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  imports: [
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCardModule
  ],
  exports:[
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,FormsModule,
    MatCardModule
  ]
})
export class MaterialModule { }
