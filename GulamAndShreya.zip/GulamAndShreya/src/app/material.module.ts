import { NgModule } from '@angular/core';
import {MatButtonModule, MatSidenav, MatNavList, MatSidenavContent, MatSidenavContainer, MatToolbarModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import {MatListModule} from '@angular/material/list';
import {MatGridListModule} from '@angular/material/grid-list';
@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatIconModule,MatToolbarModule,
    MatListModule,
    MatGridListModule,
    MatCardModule
  ],
  exports:[
    MatButtonModule,MatMenuModule,MatIconModule,MatToolbarModule,
    MatGridListModule,
    MatListModule,
    MatCardModule
  ]
})
export class MaterialModule { }
