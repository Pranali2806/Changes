import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { CommonAdminService } from '../service/common-admin.service';



@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  customerArr: CustomerModel[];

  constructor(private service: CommonAdminService) {
    this.customerArr = [];
  }

  ngOnInit() {

   this.service.getCustomerDetails().subscribe(data=>{
     this.customerArr=data;
     })
  }
}
