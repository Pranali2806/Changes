import { NgModule } from '@angular/core';
import {MatButtonModule, MatSidenav, MatNavList, MatSidenavContent, 
  MatSidenavContainer, MatToolbarModule, MatDatepickerModule, MatDatepicker, MatNativeDateModule, MatRadioModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import {MatListModule} from '@angular/material/list';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatInputModule} from '@angular/material/input';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSelectModule} from '@angular/material/select';
@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatIconModule,MatToolbarModule,
    MatListModule,
    MatGridListModule,
    MatCardModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatTableModule,
    MatSelectModule,
    MatRadioModule
  ],
  exports:[
    MatButtonModule,MatMenuModule,MatIconModule,MatToolbarModule,
    MatGridListModule,
    MatListModule,
    MatCardModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatTableModule,
    MatSelectModule,
    MatRadioModule
  ]
})
export class MaterialModule { }
