import { Component, Input, OnInit } from '@angular/core';
import { Merchant } from '../model/ManageMerchant';
import { MerchantServiceService } from '../Service/merchant-service.service';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-add-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class AddMerchantComponent implements OnInit {

  hide=true;
  merchant = new Merchant();
  merchantArr: Merchant[] = [];
  mobileNoControl =  new FormControl('', [Validators.required, Validators.pattern('^[0-9]{10}')]);
  email = new FormControl('', [Validators.required, Validators.email]);
  constructor(private merchantService: MerchantServiceService,  private router: Router) {

    this.merchant = new Merchant();
  }

  ngOnInit() {
  }

  getErrorMessage() {
    return this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  getErrorMessageMobile() {
    return this.mobileNoControl.hasError('pattern')
      ? 'Not a valid mobile number'
      : '';
  }

  addMerchant() {

    this.merchantService.add(this.merchant).subscribe(
      result => {
        console.log(result);
        console.log("Added Successfully");
        // if added successfully
        this.router.navigate(['/merchantdetails']);
        alert("Data Added Successfully");
        this.merchant = new Merchant();
        
      }, error => { console.log(error) }
    )
    
  }



}
