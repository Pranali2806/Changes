import { Component, OnInit } from '@angular/core';
import { InventoryModel } from '../model/inventory';
import { GoodserviceService } from '../Service/goodservice.service';

@Component({
  selector: 'app-returngoods',
  templateUrl: './returngoods.component.html',
  styleUrls: ['./returngoods.component.css']
})
export class ReturngoodsComponent implements OnInit {

allProducts: InventoryModel[] =[];
  router: any;

  constructor(private service : GoodserviceService) { 

    
   
  }

  ngOnInit() {
    this.getAll();
  }
 

getAll(){
  this.service.getAll().subscribe(
result => {
  this.allProducts = result;
  console.log(this.allProducts);
  }
  );
}
}
