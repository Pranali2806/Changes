import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-returnmessage',
  templateUrl: './returnmessage.component.html',
  styleUrls: ['./returnmessage.component.css']
})
export class ReturnmessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
