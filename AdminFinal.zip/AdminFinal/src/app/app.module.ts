import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';
import { InventoryDetailsComponent } from './inventory-details/inventory-details.component';
import { HttpClientModule } from '@angular/common/http';
import {MatSidenavModule} from '@angular/material/sidenav';
import { CouponComponent } from './coupon/coupon.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OptionpageComponent } from './optionpage/optionpage.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { SendInvitationComponent } from './send-invitation/send-invitation.component';
import { AddreportComponent } from './addreport/addreport.component';
import { RefundComponent } from './refund/refund.component';
import { ReportComponent } from './report/report.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ReturnpageComponent } from './returnpage/returnpage.component';
import { ReturnmessageComponent } from './returnmessage/returnmessage.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerDetailsComponent,
    MerchantDetailsComponent,
    InventoryDetailsComponent,
    CouponComponent,
    OptionpageComponent,
    AddMerchantComponent,
    DeleteMerchantComponent,
    SendInvitationComponent,
    AddreportComponent,
    RefundComponent,
    ReportComponent,
    ReturngoodsComponent,
    ReturnmessageComponent,
    ReturnpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    MatSidenavModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule {

}
