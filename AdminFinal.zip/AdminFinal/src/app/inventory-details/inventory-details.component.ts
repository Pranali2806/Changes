import { Component, OnInit } from '@angular/core';
import { InventoryModel } from '../model/inventory';

import { CommonAdminService } from '../service/common-admin.service';

@Component({
  selector: 'app-inventory-details',
  templateUrl: './inventory-details.component.html',
  styleUrls: ['./inventory-details.component.css']
})
export class InventoryDetailsComponent implements OnInit {
  inventoryArr: InventoryModel[];
  inventoryArray;
  actualPrice;
  discount;
  similarProduct: string[] = ['assets/images/test1.jpg', 'assets/images/test2.jpg', 'assets/images/test3.jpg',
   'assets/images/test3.jpg', 'assets/images/test1.jpg',
  'assets/images/test2.jpg', 'assets/images/test3.jpg', 'assets/images/test2.jpg', 'assets/images/test1.jpg', 'assets/images/test2.jpg',
  'assets/images/test3.jpg'];
  sp = 'assets/images/test1.jpg';
  constructor(private service: CommonAdminService) {
    this.inventoryArr = [];
  }

  ngOnInit() {
    
    this.service.getInventoryDetails().subscribe(data => {
      this.inventoryArr = data;
      console.log(this.inventoryArr);
      // this.actualPrice = this.inventoryArr.inventoryFromProduct["0"]["price"];
      // this.discount = Math.floor((2000/this.actualPrice) *100);
    });
   
  }
  delete(id) {
    this.service.deleteProduct(id).subscribe(data=>{
      console.log(data);
      })
  }

}
