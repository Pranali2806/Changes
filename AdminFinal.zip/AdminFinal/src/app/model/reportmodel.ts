// This is bean class for report 
export class ReportModel {
    public reportId: number;
    public reportComment: String;
    public customerName: String;
}
