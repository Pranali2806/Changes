export class InventoryModel {
    public productId: number;
    public merchantId: number;
    public productDescription: string;
    public productPrice: number;
    public productQuantity: number;
}