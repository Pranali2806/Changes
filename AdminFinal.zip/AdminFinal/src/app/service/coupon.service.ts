import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CouponFields } from '../model/add-coupon';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CouponService {
  baseHref = 'http://localhost:8888';
  constructor(private routes: Router, private http: HttpClient) { }

  add(coupon: CouponFields) {
    console.log(coupon);
    return this.http.post<string>(this.baseHref + '/add', coupon);
  }
}
